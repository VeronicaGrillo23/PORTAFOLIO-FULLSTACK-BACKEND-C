#include <stdio.h>

int main(void)
{
printf("Hola Mundo\n");
return 0;
//system("PAUSE");
}


//int x y;
//x = 10;
//if (x < y);

//{
//else
//}

//while (x > y)//en vez de for
//{

//}

//entrada y salida
//printf ademas de imprimir string solos puede imprimir cosas mas complejas, existen los comodines % de, 
//lo que hara es esperar una variable despues de la coma
// tantos por cientos hay debe haber igual cantidad de variables
//usar estandar de int usar %d para enteros
//
//\n proboca salto de linea
//puedo poner tantos %d como me hagan falta debo poner las variables luego de comida y comas
//scanf si necesito que digite por pantañlla
//int x;
//scanf("%d", &x); lo guarda en x  scanf("%d %d", &x, &y);
//
//

