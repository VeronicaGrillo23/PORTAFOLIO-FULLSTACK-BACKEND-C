#include <stdio.h>
int main(void)
{
int x, y, z;
printf("Coloque el valor de las variables x y z\n");
scanf("%d %d %d", &x, &y, &z);
printf("los valores son %d %d %d", x, y, z);
return 0;
}

