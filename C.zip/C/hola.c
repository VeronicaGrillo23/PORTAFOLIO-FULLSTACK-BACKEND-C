/*inclusi�n biblioteca estandar */
#include <stdio.h>
/* main devuelve un int, no toma argumentos */ 
int main(void)
{
	printf("Hola Mundo\n");
/* resultado de la funci�n */
	return 0;
//	system("PAUSE");
}
