#include <stdio.h>
int main(void)
{
int x, y;
x = 3;
y = 1;
printf("Ingrese el valor inicial sigma 0 de x e y\n");
scanf("%d" "%d", &x, &y);
if(x >= y)
{
printf("el estado sigma 1 de x es %d y el de y es %d \n",x, y);	
x = 0,
printf("\nel estado sigma 2 de x es %d y el de y es %d \n",x, y);	
}
else if(x <= y)
{
printf("el estado sigma 1 prima de x es %d y el de y es %d \n",x, y);	
x = 2,
printf("\nel estado sigma 2 prima de x es %d y el de y es %d \n",x, y);	
}
printf("\nel estado sigma tres es x = 0 e y = 1");
return 0;
}

