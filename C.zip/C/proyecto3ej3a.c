#include <stdio.h>
int main(void)
{
int x;
x = 1;
printf("Ingrese el valor de x\n");
scanf("%d", &x);
x = 5;
printf("el estado final es x = %d \n",x);

printf("Ingrese el valor de x\n");
scanf("%d", &x);
x = 5;
printf("el estado final es x = %d \n",x);

printf("Ingrese el valor de x\n");
scanf("%d", &x);
x = 5;
printf("el estado final es x = %d \n",x);
return 0;
}

