#include <stdio.h>

void imprimeHola()
{
printf("\nHola!\n");
}

void imprimeChau()
{
printf("\nChau!\n");
}

int main(void)
{ 
imprimeHola();
imprimeHola();
imprimeChau();
imprimeChau();

return 0;
}


















